$(function () {
   formatFields();
});

function formatFields() {
    $('.phone, .id-card').mask('000 000 0000');
}
