$(function () {
    $('.select2').select2();
    $('.select2-no-search').select2({
        minimumResultsForSearch: -1
    });
});
