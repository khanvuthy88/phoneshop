$(function () {
    callFileInput('#site_logo', 1, 5120, ['jpg', 'jpeg', 'png']);
});
