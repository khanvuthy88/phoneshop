$(function() {
    tinymce.init({
        selector: 'textarea.tinymce',
        height: 200,
        plugins: "advlist autolink code contextmenu insertdatetime link lists placeholder preview searchreplace spellchecker wordcount",
    })
});
