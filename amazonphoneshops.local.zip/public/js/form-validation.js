$(function () {
    $('.validated-form').validate();
});
