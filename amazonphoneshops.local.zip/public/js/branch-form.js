$(function () {
    callFileInput('#first_logo, #second_logo', 1, 5120, ['jpg', 'jpeg', 'png']);
});
