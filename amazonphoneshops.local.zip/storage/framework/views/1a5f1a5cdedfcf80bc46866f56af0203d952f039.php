<?php $__env->startSection('title', trans('app.loan')); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.loan_report') . ' - ' . reportLoanStatuses($status)); ?></h3>
            <div class="row">
                <div class="col-md-12">
                    
                    <a href="<?php echo e(route('report.loan', ReportLoanStatus::PENDING)); ?>" class="btn btn-warning font-size-16 mb-1 mr-1">
                        <?php echo e(trans('app.pending')); ?> : <span class="text-white font-bold"><?php echo e($pendingLoanCount); ?></span>
                    </a>

                    
                    <a href="<?php echo e(route('report.loan', ReportLoanStatus::ACTIVE)); ?>" class="btn btn-info font-size-16 mb-1 mr-1">
                        <?php echo e(trans('app.progressing')); ?> : <span class="text-white font-bold"><?php echo e($activeLoanCount); ?></span>
                    </a>

                    
                    <a href="<?php echo e(route('report.loan', ReportLoanStatus::PAID)); ?>" class="btn btn-success font-size-16 mb-1 mr-1">
                        <?php echo e(trans('app.paid')); ?> : <span class="text-white font-bold"><?php echo e($paidLoanCount); ?></span>
                    </a>

                    
                    <a href="<?php echo e(route('report.loan', ReportLoanStatus::REJECTED)); ?>" class="btn btn-danger font-size-16 mb-1 mr-1">
                        <?php echo e(trans('app.rejected')); ?> : <span class="text-white font-bold"><?php echo e($rejectedLoanCount); ?></span>
                    </a>
                </div>
            </div>
            <hr>

            <?php echo $__env->make('partial.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partial.item-count-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <?php
                        $isRejectedLoan = ($status == ReportLoanStatus::REJECTED);
                        $statusTitle = reportLoanStatuses($status);

                        switch ($status) {
                            case ReportLoanStatus::PENDING:
                                $labelClass = 'badge badge-warning';
                                break;
                            case ReportLoanStatus::ACTIVE:
                                $labelClass = 'badge badge-info';
                                break;
                            case ReportLoanStatus::PAID:
                                $labelClass = 'badge badge-success';
                                break;
                            case ReportLoanStatus::REJECTED:
                                $labelClass = 'badge badge-danger';
                                break;
                        }
                    ?>

                    <thead>
                        <tr>
                            <th><?php echo e(trans('app.no_sign')); ?></th>
                            <th><?php echo e(trans('app.client')); ?></th>
                            <th><?php echo e(trans('app.profile_photo')); ?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('client_code', trans('app.client_code')));?></th>
                            <th><?php echo e(trans('app.first_phone')); ?></th>
                            <th><?php echo e(trans('app.branch')); ?></th>

                            <?php if(isAdmin()): ?>
                                <th><?php echo e(trans('app.agent')); ?></th>
                            <?php endif; ?>

                            <th><?php echo e(trans('app.product')); ?></th>
                            <th><?php echo e(trans('app.status')); ?></th>

                            <?php if(isAdmin() && $isRejectedLoan): ?>
                                <th><?php echo e(trans('app.action')); ?></th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $filteredLoans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($offset++); ?></td>
                                <td><?php echo $__env->make('partial.client-detail-link', ['client' => $loan->client], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo $__env->make('partial.client-profile-photo', ['client' => $loan->client], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>

                                <td>
                                    <?php if($isRejectedLoan): ?>
                                        <?php echo e($loan->client_code); ?>

                                    <?php else: ?>
                                        <?php echo $__env->make('partial.loan-detail-link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php endif; ?>
                                </td>

                                <td><?php echo e($loan->client->first_phone); ?></td>
                                <td><?php echo e($loan->branch->location ?? trans('app.n/a')); ?></td>

                                <?php if(isAdmin()): ?>
                                    <td><?php echo $__env->make('partial.staff-detail-link', ['staff' => $loan->staff], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <?php endif; ?>

                                <td><?php echo $__env->make('partial.product-detail-link', ['product' => $loan->product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><label class="<?php echo e($labelClass); ?>"><?php echo e($statusTitle); ?></label></td>

                                <?php if(isAdmin() && $isRejectedLoan): ?>
                                    <td class="text-center">
                                        
                                        <button type="button" class="btn btn-primary btn-sm btn-revert mb-1"
                                            data-redirect-url="<?php echo e(route('loan.show', $loan->id)); ?>"
                                            data-revert-url="<?php echo e(route('loan.change_status', [$loan->id, LoanStatus::PENDING])); ?>">
                                            <?php echo e(trans('app.revert')); ?>

                                        </button>

                                        
                                        <button type="button" class="btn btn-danger btn-sm btn-delete mb-1"
                                            data-url="<?php echo e(route('loan.destroy', $loan->id)); ?>">
                                            <?php echo e(trans('app.delete')); ?>

                                        </button>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $filteredLoans->appends(Request::except('page'))->render(); ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/rejected-loan.js')); ?>"></script>
    <script src="<?php echo e(asset('js/delete-item.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>