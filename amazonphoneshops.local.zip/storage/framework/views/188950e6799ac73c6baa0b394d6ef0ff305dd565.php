<?php $__env->startSection('title', trans('app.stock_adjustment')); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.stock_adjustment')); ?></h3>
            <?php echo $__env->make('partial/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card">
                <div class="card-header">
                    <form method="get" action="">
                        <div class="row">
                            <div class="col-lg-6">
                                <?php echo $__env->make('partial.anchor-create', [
                                    'href' => route('adjustment.create')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                            <div class="col-lg-6">
                                <?php echo $__env->make('partial.search-input-group', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <br>

            <?php echo $__env->make('partial.item-count-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th><?php echo e(trans('app.no_sign')); ?></th>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('adjustment_date', trans('app.adjustment_date')));?></td>
                            <th><?php echo e(trans('app.location')); ?></th>
                            <th><?php echo e(trans('app.product')); ?></th>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('quantity', trans('app.quantity')));?></td>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('action', trans('app.adjustment_action')));?></td>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('reason', trans('app.reason')));?></td>
                            <th><?php echo e(trans('app.creator')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $adjustments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjustment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($offset++); ?></td>
                                <td><?php echo e(displayDate($adjustment->adjustment_date)); ?></td>
                                <td><?php echo $__env->make('partial.branch-detail-link', ['branch' => $adjustment->warehouse], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo $__env->make('partial.product-detail-link', ['product' => $adjustment->product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo e($adjustment->quantity); ?></td>
                                <td><?php echo e(stockTypes($adjustment->action)); ?></td>
                                <td><?php echo e($adjustment->reason); ?></td>
                                <td><?php echo e($adjustment->creator->name ?? trans('app.n/a')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $adjustments->appends(Request::except('page'))->render(); ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select-box.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>