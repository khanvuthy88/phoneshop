<?php $__env->startSection('title', trans('app.product')); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $isFormShowType = ($formType == FormType::SHOW_TYPE);
        $disabledFormType = ($isFormShowType ? 'disabled' : '');
    ?>

    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.product') . ' - ' . $title); ?></h3>
            <?php echo $__env->make('partial/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form id="form-product" method="post" action="<?php echo e(route('product.save', $product)); ?>" enctype="multipart/form-data">
                <input type="hidden" name="form_type" value="<?php echo e($formType); ?>">
                <?php echo csrf_field(); ?>

                
                <div class="row">
                    <div class="col-lg-12 text-right">
                        <?php if($isFormShowType): ?>
                            <?php echo $__env->make('partial/anchor-edit', [
                                'href' => route('product.edit', $product->id)
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php else: ?>
                            <?php echo $__env->make('partial/button-save', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="name" class="control-label">
                            <?php echo e(trans('app.name')); ?> <span class="required">*</span>
                        </label>
                        <input type="text" name="name" id="name" class="form-control"
                               value="<?php echo e(old('name') ?? $product->name); ?>" required <?php echo e($disabledFormType); ?>>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="category" class="control-label">
                            <?php echo e(trans('app.product_category')); ?> <span class="required">*</span>
                        </label>
                        <?php if($isFormShowType): ?>
                            <input type="text" class="form-control" value="<?php echo e($product->category->value ?? trans('app.n/a')); ?>" disabled>
                        <?php else: ?>
                            <select name="category" id="category" class="form-control select2" required>
                                <option value=""><?php echo e(trans('app.select_option')); ?></option>
                                <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(selectedOption($category->id, old('category'), $product->category_id)); ?>>
                                        <?php echo e($category->value); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="brand" class="control-label">
                            <?php echo e(trans('app.brand')); ?> <span class="required">*</span>
                        </label>
                        <?php if($isFormShowType): ?>
                            <input type="text" class="form-control" value="<?php echo e(brands($product->brand ?? '')); ?>" disabled>
                        <?php else: ?>
                            <select name="brand" id="brand" class="form-control select2" required>
                                <option value=""><?php echo e(trans('app.select_option')); ?></option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand->id); ?>" <?php echo e(selectedOption($brand->id, old('brand'), $product->brand)); ?>>
                                        <?php echo e($brand->value); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="product_code" class="control-label">
                            <?php echo e(trans('app.product_code/sku')); ?> <span class="required">*</span>
                        </label>
                        <div class="input-group">
                            <input type="text" name="product_code" id="product_code" class="form-control integer-input" required
                                   placeholder="<?php echo e(trans('app.code') . ' *'); ?>" value="<?php echo e(old('product_code') ?? $product->code); ?>">
                            <button type="button" id="generate-code" class="btn btn-primary"><?php echo e(trans('app.generate')); ?></button>
                            <input type="text" name="product_sku" id="product_sku" class="form-control ml-2"
                                   placeholder="<?php echo e(trans('app.sku')); ?>" value="<?php echo e(old('product_sku') ?? $product->sku); ?>">
                        </div>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="cost" class="control-label">
                            <?php echo e(trans('app.cost')); ?> ($)
                        </label>
                        <input type="text" name="cost" id="cost" class="form-control decimal-input"
                               value="<?php echo e(old('cost') ?? $product->cost); ?>" <?php echo e($disabledFormType); ?>>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="price" class="control-label">
                            <?php echo e(trans('app.selling_price')); ?> ($) <span class="required">*</span>
                        </label>
                        <input type="text" name="price" id="price" class="form-control decimal-input"
                               value="<?php echo e(old('price') ?? $product->price); ?>" required <?php echo e($disabledFormType); ?>>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="alert_quantity" class="control-label">
                            <?php echo e(trans('app.alert_quantity')); ?> <span class="required">*</span>
                        </label>
                        <input type="text" name="alert_quantity" id="alert_quantity" class="form-control integer-input"
                               value="<?php echo e(old('alert_quantity') ?? $product->alert_quantity); ?>" required>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="description" class="control-label">
                            <?php echo e(trans('app.description')); ?>

                        </label>
                        <input type="text" name="description" id="description" class="form-control"
                               value="<?php echo e(old('description') ?? $product->description); ?>" <?php echo e($disabledFormType); ?>>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="photo" class="control-label">
                            <?php echo e(trans('app.photo')); ?> <?php if(empty($product->photo)): ?> <span class="required">*</span> <?php endif; ?>
                        </label>
                        <?php if($isFormShowType): ?>
                            <div class="text-left">
                                <?php if(isset($product->photo)): ?>
                                    <img src="<?php echo e(asset($product->photo)); ?>" alt="" width="100%" class="img-responsive">
                                <?php else: ?>
                                    <?php echo e(trans('app.no_picture')); ?>

                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <input type="file" name="photo" id="photo" class="form-control" accept=".jpg, .jpeg, .png"
                                   <?php if(empty($product->photo)): ?> required <?php endif; ?>>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-lg-12 text-right">
                        <?php if($isFormShowType): ?>
                            <?php echo $__env->make('partial/anchor-edit', [
                                'href' => route('product.edit', $product->id)
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php else: ?>
                            <?php echo $__env->make('partial/button-save', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/bootstrap-fileinput.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-fileinput-fa-theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/init-file-input.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-number.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/number.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-mask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mask.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select-box.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/product.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>