<a href="<?php echo e($href); ?>" class="btn btn-success mb-1 <?php echo e($class ?? ''); ?>" title="<?php echo e(trans('app.create')); ?>">
    <i class="fa fa-plus-circle pr-1"></i> <?php echo e(trans('app.create')); ?>

</a>
