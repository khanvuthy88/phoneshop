<a href="<?php echo e(route('client.show', $client)); ?>"><?php echo e($client->name); ?></a>
