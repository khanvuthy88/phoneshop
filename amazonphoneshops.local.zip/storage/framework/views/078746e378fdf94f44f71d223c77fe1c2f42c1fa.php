<?php if($scheduleType == PaymentScheduleType::FLAT_INTEREST): ?>
    <th><?php echo e(trans('app.payment_amount')); ?></th>
<?php else: ?>
    <th><?php echo e(trans('app.total')); ?></th>
    <th><?php echo e(trans('app.principal')); ?></th>
    <th><?php echo e(trans('app.interest')); ?></th>
<?php endif; ?>
