<button type="submit" class="btn btn-success <?php echo e($class ?? ''); ?>">
    <i class="fa fa-search pr-1"></i> <?php echo e(trans('app.search')); ?>

</button>
