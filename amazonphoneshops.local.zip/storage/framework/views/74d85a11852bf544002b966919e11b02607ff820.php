<?php if($scheduleType == PaymentScheduleType::FLAT_INTEREST): ?>
    <td><?php echo e(($currencySign ?? '') . number_format($schedule->principal)); ?></td>
<?php else: ?>
    <?php $decimalNumber = ($schedule->interest == 0 ? 2 : 0) ?>
    <td><b><?php echo e(($currencySign ?? '') . number_format($schedule->total, $decimalNumber)); ?></b></td>
    <td><?php echo e(($currencySign ?? '') . number_format($schedule->principal, $decimalNumber)); ?></td>
    <td><?php echo e(($currencySign ?? '') . number_format($schedule->interest)); ?></td>
<?php endif; ?>
