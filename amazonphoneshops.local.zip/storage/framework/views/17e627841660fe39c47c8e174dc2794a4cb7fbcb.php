<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo e($generalSetting->site_title . ' - ' . trans('app.contract')); ?></title>
	<meta charset="utf-8">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo e(asset($generalSetting->site_logo)); ?>" sizes="32x32">
    <link  rel="stylesheet" href="https://fonts.googleapis.com/css?family=Battambang|Moul">
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<style>
        .content-wrapper {
            margin: 0 auto;
            width: 800px;
            padding: 10px;
        }

        .moul-font {
            font-family: 'Moul', 'Arial Black', sans-serif !important;
        }
        
        table thead th {
            text-align: center;
        }

        .table-bordered {
            border: 1px solid #000;
        }

        .table-bordered th,
        .table-bordered td {
            border: 1px solid #000 !important;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Moul', 'Arial Black', sans-serif !important;

        }

        p, th, td, li, span {
            font-size: 12px !important;
            font-family: 'Battambang', Arial, sans-serif !important;
        }

        p, li, span {
            line-height: 1.8;
        }

        .content-header {
            margin-bottom: 20px;
        }

        .content-header .left-logo-wrapper {
            padding-right: 0 !important;
        }

        .content-header .right-logo-wrapper {
            padding-left: 0 !important;
        }
        .content-header .branch-name {
            margin-bottom: 25px;
            font-size: 24px;
        }

        .content-header .sub-title {
            margin-bottom: 30px;
            font-size: 16px;
        }

        .content-body .table-info td {
            padding-right: 7px;
            padding-bottom: 5px;
        }

        .content-body #table-schedule {
            margin-top: 20px;
            margin-bottom: 15px;
        }

        #table-schedule caption {
            font-weight: 700;
            font-size: 13px !important;
            font-family: 'Battambang', Arial, sans-serif !important;
            color: #333;
        }

        .content-body .contract-text {
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .content-body .date-wrapper {
            position: relative;
            right: 108px;
        }

        .content-body .thumbprint-content {
            margin-bottom: 110px;
        }

        .thumbprint-content p {
            font-weight: 600;
            font-size: 16px;
        }

        .thumbprint-footer h6 {
            font-weight: 700;
            font-size: 13px;
            font-family: 'Battambang', Arial, sans-serif !important;
        }

        .content-footer .footer-ruler {
            width: 100%;
            margin-bottom: 10px;
            border: 1px solid #000;
        }

        .pl-0 {
            padding-left: 0 !important;
        }

		@media  print {
			body {
				width: 21cm;
				height: 29.7cm;
				margin: 5mm;
			}

            .content-footer {
                position: fixed;
                bottom: 0;
                right: 0;
                width: 100%;
            }
		}
	</style>
</head>
<body>
    <?php
        $branch = $loan->branch;
        $client = $loan->client;
    ?>

	<div class="content-wrapper">
        <div class="row">
            <div class="col-xs-12">
                <div class="content-header">
                    <div class="row">
                        <div class="col-xs-2 left-logo-wrapper">
                            <img src="<?php echo e(asset($branch->logo ?? 'images/contract-phone-1.jpg')); ?>"
                                 width="90" height="120" alt="" class="pull-right">
                        </div>
                        <div class="col-xs-8 text-center">
                            <h1 class="branch-name"><?php echo e($loan->branch->name); ?></h1>
                            <h6 class="sub-title"><?php echo e(trans('app.contract_and_payment_schedule') . ' ' . $loan->branch->location); ?></h6>
                        </div>
                        <div class="col-xs-2 right-logo-wrapper">
                            <img src="<?php echo e(asset($branch->logo_2 ?? 'images/contract-phone-2.jpg')); ?>" width="90" height="120" alt="">
                        </div>
                    </div>
                </div>
                <div class="content-body">
                    <div class="row">
                        <div class="col-xs-8">
                            <table class="table-info" border="0">
                                <tbody>
                                    <tr>
                                        <td><?php echo e(trans('app.loan_code')); ?></td>
                                        <td>: <?php echo $loan->account_number . '/<b>' . $loan->client_code . '</b>'; ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.wing_account_number')); ?></td>
                                        <td>: <?php echo e($loan->wing_code); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.client_name')); ?></td>
                                        <td>
                                            : <span class="moul-font"><?php echo e($client->name); ?></span>,
                                            <?php echo e(trans('app.id_card_number')); ?> : <?php echo e($client->id_card_number); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.phone_number')); ?></td>
                                        <td>
                                            : <?php echo e($client->first_phone); ?>

                                            <?php echo e(isset($client->second_phone) ? ' / ' . $client->second_phone : ''); ?>

                                        </td>
                                    </tr>

                                    <tr>
                                        <td><?php echo e(trans('app.address')); ?></td>
                                        <td>:
                                            <?php if(isset($client->province_id) || isset($client->district_id) || isset($client->commune_id)): ?>
                                                <?php echo e(isset($client->commune->name) ? $client->commune->name . ', ' : ''); ?>

                                                <?php echo e(isset($client->district->name) ? $client->district->name . ', ' : ''); ?>

                                                <?php echo e(isset($client->province->name) ? $client->province->name : ''); ?>

                                            <?php else: ?>
                                                <?php echo e(trans('app.n/a')); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    
                                    <?php if(!empty($client->sponsor_name)): ?>
                                        <tr>
                                            <td><?php echo e(trans('app.sponsor_name')); ?></td>
                                            <td>
                                                : <span class="moul-font"><?php echo e($client->sponsor_name); ?></span>,
                                                <?php echo e(trans('app.id_card_number')); ?> : <?php echo e($client->sponsor_id_card ?? trans('app.none')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e(trans('app.phone_number')); ?></td>
                                            <td>
                                                <?php if(!empty($client->sponsor_phone) || !empty($client->sponsor_phone_2)): ?>
                                                    : <?php echo e($client->sponsor_phone); ?>

                                                    <?php echo e(!empty($client->sponsor_phone) && !empty($client->sponsor_phone_2) ? ' / ' : ''); ?>

                                                    <?php echo e($client->sponsor_phone_2); ?>

                                                <?php else: ?>
                                                    <?php echo e(trans('app.none')); ?>

                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-xs-4 pl-0">
                            <table class="table-info" border="0">
                                <tbody>
                                    <tr>
                                        <td><?php echo e(trans('app.product')); ?></td>
                                        <td>: <?php echo e($loan->product->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.product_price')); ?></td>
                                        <td>: $ <?php echo e(decimalNumber($loan->loan_amount, true)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.depreciation_amount')); ?></td>
                                        <td>: $ <?php echo e(decimalNumber($loan->depreciation_amount, true)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.loan_amount')); ?></td>
                                        <td>: $ <?php echo e(decimalNumber($loan->down_payment_amount, true)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.start_date')); ?></td>
                                        <td>: <?php echo e(displayDate($loan->loan_start_date)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.end_date')); ?></td>
                                        <td>: <?php echo e(displayDate($loan->schedules[$loan->installment - 1]->payment_date)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(trans('app.duration')); ?></td>
                                        <td>: <?php echo e($loan->installment . ' ' . trans('app.month')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="table-schedule" class="table table-bordered">
                            
                            <thead>
                                <tr>
                                    <th><?php echo e(trans('app.no_sign')); ?></th>
                                    <th><?php echo e(trans('app.payment_date')); ?></th>
                                    <?php echo $__env->make('partial.schedule-type-table-header', ['scheduleType' => $loan->schedule_type], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <th><?php echo e(trans('app.outstanding')); ?></th>
                                    <th><?php echo e(trans('app.paid_date')); ?></th>
                                    <th><?php echo e(trans('app.paid_amount')); ?></th>
                                    <th><?php echo e(trans('app.signature')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $loan->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(displayDate($schedule->payment_date)); ?></td>
                                        <?php echo $__env->make('partial.schedule-type-table-data', [
                                            'scheduleType' => $loan->schedule_type,
                                            'currencySign' => '$ '
                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <td>$ <?php echo e(decimalNumber($schedule->outstanding, true)); ?></td>
                                        <td><?php echo e(displayDate($schedule->paid_date)); ?></td>
                                        <td><?php echo e(isset($schedule->paid_total) ? '$ ' . decimalNumber($schedule->paid_total, true) : ''); ?></td>
                                        <td></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="contract-text">
                        <?php echo $loan->branch->contract_text; ?>

                    </div>
                    <div class="date-wrapper text-right">
                        <p>ភ្នំពេញ, ថ្ងៃទី <?php echo e(date('d')); ?> ខែ <?php echo e(date('m')); ?> ឆ្នាំ <?php echo e(date('Y')); ?></p>
                    </div>
                    <div class="thumbprint-content">
                        <div class="row">
                            <div class="col-xs-4">
                                <p><?php echo e(trans('app.client_name')); ?></p>
                            </div>
                            <div class="col-xs-4">
                                <p><?php echo e(trans('app.sponsor_name')); ?></p>
                            </div>
                            <div class="col-xs-4">
                                <p><?php echo e(trans('app.company_owner_name')); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="thumbprint-footer">
                        <div class="row">
                            <div class="col-xs-4">
                                <h5><?php echo e($client->name); ?></h5>
                            </div>
                            <div class="col-xs-4">
                                <h5><?php echo e($client->sponsor_name); ?></h5>
                            </div>
                            <div class="col-xs-4">
                                <h5>ប៊ុន រ៉ូនី</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-footer">
                    <hr class="footer-ruler">
                    <div class="bottom-footer">
                        <div class="row">
                            <div class="col-xs-6">
                                <p><?php echo e(trans('app.address') . ': ' . $loan->branch->address); ?></p>
                            </div>
                            <div class="col-xs-6 text-right">
                                <p>Tel:
                                    <?php echo e($loan->branch->phone_1
                                       . (isset($loan->branch->phone_2) ? '/' . $loan->branch->phone_2 : '')
                                       . (isset($loan->branch->phone_3) ? '/' . $loan->branch->phone_3 : '')
                                       . (isset($loan->branch->phone_4) ? '/' . $loan->branch->phone_4 : '')); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
