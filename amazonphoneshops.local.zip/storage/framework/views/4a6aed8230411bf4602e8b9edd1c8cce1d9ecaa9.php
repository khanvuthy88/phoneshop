<?php $__env->startSection('title', trans('app.stock_transfer')); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<main class="app-content">
    <div class="tile">
        <h3 class="page-heading"><?php echo e(trans('app.stock_transfer') . ' - ' . trans('app.detail')); ?></h3>
        <?php echo $__env->make('partial.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
            <div class="col-lg-6">
                <h5><?php echo e(trans('app.transfer_info')); ?></h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <tbody>
                            <tr>
                                <td width="30%"><?php echo e(trans('app.transfer_date')); ?></td>
                                <td><?php echo e(displayDate($transfer->transfer_date)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.transfer_status')); ?></td>
                                <td><?php echo $__env->make('partial.transfer-status-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.original_location')); ?></td>
                                <td><?php echo $__env->make('partial.branch-detail-link', ['branch' => $transfer->fromWarehouse], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.target_location')); ?></td>
                                <td><?php echo $__env->make('partial.branch-detail-link', ['branch' => $transfer->toWarehouse], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.invoice_id')); ?></td>
                                <td><?php echo e($transfer->reference_no); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.shipping_cost')); ?></td>
                                <td>$ <?php echo e(decimalNumber($transfer->shipping_cost, true)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.document')); ?></td>
                                <td><?php echo $__env->make('partial.transfer-doc-view', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.note')); ?></td>
                                <td><?php echo $transfer->note; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-6">
                <h5><?php echo e(trans('app.product_table')); ?></h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th><?php echo e(trans('app.no_sign')); ?></th>
                                <th><?php echo e(trans('app.product')); ?></th>
                                <th><?php echo e(trans('app.quantity')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transfer->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transferDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo $__env->make('partial.product-detail-link', ['product' => $transferDetail->product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                    <td><?php echo e($transferDetail->quantity); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>