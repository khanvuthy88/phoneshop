<?php $statusLabel = saleStatuses($sale->status) ?>
<?php switch($sale->status):
    case (SaleStatus::DRAFT): ?>
        <label class="badge badge-warning"><?php echo e($statusLabel); ?></label>
        <?php break; ?>
    <?php case (SaleStatus::PENDING): ?>
        <label class="badge badge-warning"><?php echo e($statusLabel); ?></label>
        <?php break; ?>
    <?php case (SaleStatus::ACTIVE): ?>
        <label class="badge badge-info"><?php echo e($statusLabel); ?></label>
        <?php break; ?>
    <?php case (SaleStatus::PAID): ?>
        <label class="badge badge-success"><?php echo e($statusLabel); ?></label>
        <?php break; ?>
<?php endswitch; ?>
