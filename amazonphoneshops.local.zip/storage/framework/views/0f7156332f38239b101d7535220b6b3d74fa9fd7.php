<?php if(isset($transfer->document)): ?>
    <a href="<?php echo e(asset($transfer->document)); ?>" class="btn btn-info btn-sm" target="_blank">
        <?php echo e(trans('app.view')); ?>

    </a>
<?php else: ?>
    <?php echo e(trans('app.none')); ?>

<?php endif; ?>
