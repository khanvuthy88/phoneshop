<a href="<?php echo e(route('loan.show', $loan)); ?>">
    <?php echo e($loan->client_code); ?>

</a>
