<?php $__env->startSection('title', trans('app.purchase')); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.purchase')); ?></h3>
            <?php echo $__env->make('partial/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card">
                <div class="card-header">
                    <form method="get" action="">
                        <div class="row">
                            <div class="col-lg-6">
                                <?php echo $__env->make('partial.anchor-create', [
                                    'href' => route('purchase.create')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                            <div class="col-lg-6">
                                <?php echo $__env->make('partial.search-input-group', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <br>

            <?php echo $__env->make('partial.item-count-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th><?php echo e(trans('app.no_sign')); ?></th>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('purchase_date', trans('app.purchase_date')));?></td>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('reference_no', trans('app.invoice_id')));?></td>
                            <td><?php echo e(trans('app.location')); ?></td>
                            <td><?php echo e(trans('app.document')); ?></td>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('note', trans('app.note')));?></td>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('purchase_status', trans('app.status')));?></td>
                            <td><?php echo e(trans('app.creator')); ?></td>
                            <th><?php echo e(trans('app.action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($offset++); ?></td>
                                <td><?php echo e(displayDate($purchase->purchase_date)); ?></td>
                                <td><?php echo e($purchase->reference_no); ?></td>
                                <td><?php echo $__env->make('partial.branch-detail-link', ['branch' => $purchase->warehouse], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo $__env->make('partial.purchase-doc-view', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo e($purchase->note); ?></td>
                                <td><?php echo $__env->make('partial.purchase-status-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo e($purchase->creator->name ?? trans('app.n/a')); ?></td>
                                <td class="text-center">
                                    <?php echo $__env->make('partial.anchor-show', [
                                        'href' => route('purchase.show', $purchase->id)
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $purchases->appends(Request::except('page'))->render(); ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select-box.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>