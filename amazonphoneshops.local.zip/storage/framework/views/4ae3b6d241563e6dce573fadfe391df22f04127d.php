<?php $__env->startSection('title', trans('app.branch')); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-fileinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $isFormShowType = ($formType == FormType::SHOW_TYPE);
        $disabledFormType = ($isFormShowType ? 'disabled' : '');
    ?>

    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.branch') . ' - ' . $title); ?></h3>
            <?php echo $__env->make('partial/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form action="<?php echo e(route('branch.save', $branch)); ?>" method="post" class="validated-form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
                <div class="row">
                    <div class="col-lg-12 text-right">
                        <?php if($formType == FormType::SHOW_TYPE): ?>
                            <?php echo $__env->make('partial/anchor-edit', [
                                'href' => route('branch.edit', $branch)
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php else: ?>
                            <?php echo $__env->make('partial/button-save', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="name">
                            <?php echo e(trans('app.name')); ?> <span class="required">*</span>
                        </label>
                        <input type="text" name="name" id="name" class="form-control" required
                               value="<?php echo e(old('name') ?? $branch->name); ?>" <?php echo e($disabledFormType); ?>>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="location">
                            <?php echo e(trans('app.location')); ?> <span class="required">*</span>
                        </label>
                        <input type="text" name="location" id="location" class="form-control" required
                               value="<?php echo e(old('location') ?? $branch->location); ?>" <?php echo e($disabledFormType); ?>>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="first_phone">
                            <?php echo e(trans('app.first_phone')); ?> <span class="required">*</span>
                        </label>
                        <input type="text" name="first_phone" id="first_phone" class="form-control phone"
                               value="<?php echo e(old('first_phone') ?? $branch->phone_1); ?>" required <?php echo e($disabledFormType); ?>>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="second_phone">
                            <?php echo e(trans('app.second_phone')); ?>

                        </label>
                        <input type="text" name="second_phone" id="second_phone" class="form-control phone"
                               value="<?php echo e(old('second_phone') ?? $branch->phone_2); ?>" <?php echo e($disabledFormType); ?>>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="third_phone">
                            <?php echo e(trans('app.third_phone')); ?>

                        </label>
                        <input type="text" name="third_phone" id="third_phone" class="form-control phone"
                               value="<?php echo e(old('third_phone') ?? $branch->phone_3); ?>" <?php echo e($disabledFormType); ?>>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="fourth_phone">
                            <?php echo e(trans('app.fourth_phone')); ?>

                        </label>
                        <input type="text" name="fourth_phone" id="fourth_phone" class="form-control phone"
                               value="<?php echo e(old('fourth_phone') ?? $branch->phone_4); ?>" <?php echo e($disabledFormType); ?>>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="type"><?php echo e(trans('app.branch_type')); ?> <span class="required">*</span></label>
                        <?php if($isFormShowType): ?>
                            <input type="text" class="form-control" value="<?php echo e(branchTypes($branch->type ?? '')); ?>" disabled>
                        <?php else: ?>
                            <select name="type" id="type" class="form-control select2-no-search" required>
                                <option value=""><?php echo e(trans('app.select_option')); ?></option>
                                <?php $__currentLoopData = $branchTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeKey => $typeTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($typeKey); ?>" <?php echo e(selectedOption($typeKey, old('type'), $branch->type)); ?>>
                                        <?php echo e($typeTitle); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="address"><?php echo e(trans('app.address')); ?></label>
                        <input type="text" name="address" id="address" class="form-control"
                               value="<?php echo e(old('address') ?? $branch->address); ?>" <?php echo e($disabledFormType); ?>>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="first_logo" class="control-label">
                            <?php echo e(trans('app.first_logo')); ?>

                        </label>
                        <?php if($isFormShowType): ?>
                            <div class="text-left">
                                <?php if(isset($branch->logo)): ?>
                                    <img src="<?php echo e(asset($branch->logo)); ?>" alt="" width="50%" class="img-responsive">
                                <?php else: ?>
                                    <?php echo e(trans('app.no_picture')); ?>

                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <input type="file" name="first_logo" id="first_logo" class="form-control" accept=".jpg, .jpeg, .png">
                        <?php endif; ?>
                    </div>

                    
                    <div class="col-lg-6 form-group">
                        <label for="second_logo" class="control-label">
                            <?php echo e(trans('app.second_logo')); ?>

                        </label>
                        <?php if($isFormShowType): ?>
                            <div class="text-left">
                                <?php if(isset($branch->logo_2)): ?>
                                    <img src="<?php echo e(asset($branch->logo_2)); ?>" alt="" width="50%" class="img-responsive">
                                <?php else: ?>
                                    <?php echo e(trans('app.no_picture')); ?>

                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <input type="file" name="second_logo" id="second_logo" class="form-control" accept=".jpg, .jpeg, .png">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    
                    <div class="col-lg-6 form-group">
                        <label for="contract_text">
                            <?php echo e(trans('app.contract_text')); ?>

                        </label>
                        <textarea name="contract_text" id="contract_text" class="tinymce"><?php echo e(old('contract_text') ?? $branch->contract_text); ?></textarea>
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-lg-12 text-right">
                        <?php if($formType == FormType::SHOW_TYPE): ?>
                            <?php echo $__env->make('partial/anchor-edit', [
                                'href' => route('branch.edit', $branch)
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php else: ?>
                            <?php echo $__env->make('partial/button-save', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/bootstrap-fileinput.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-fileinput-fa-theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/init-file-input.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/tinymce/tinymce.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tinymce.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select-box.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-mask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mask.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/form-validation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/branch-form.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>