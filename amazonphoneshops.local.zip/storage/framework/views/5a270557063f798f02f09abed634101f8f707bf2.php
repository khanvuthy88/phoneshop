<?php $__env->startSection('title', trans('app.commission_payment')); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.commission_payment')); ?></h3>
            <form method="get" action="<?php echo e(route('report.commission_payment')); ?>">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-6 col-md-4">
                                <label for="start_date"><?php echo e(trans('app.start_date')); ?></label>
                                <input type="text" name="start_date" id="start_date" class="form-control date-picker"
                                       value="<?php echo e(request('start_date')); ?>" placeholder="<?php echo e(trans('app.date_placeholder')); ?>">
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <label for="end_date"><?php echo e(trans('app.end_date')); ?></label>
                                <input type="text" name="end_date" id="end_date" class="form-control date-picker"
                                       value="<?php echo e(request('end_date')); ?>" placeholder="<?php echo e(trans('app.date_placeholder')); ?>">
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <?php echo $__env->make('partial.button-search', [
                                    'class' => 'mt-4'
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <br>
            <?php echo $__env->make('partial.item-count-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered">
                    <thead>
                        <tr>
                            <th><?php echo e(trans('app.no_sign')); ?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('paid_date', trans('app.paid_date')));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('amount', trans('app.paid_amount')));?></th>
                            <th><?php echo e(trans('app.agent')); ?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('receipt_reference', trans('app.reference_number')));?></th>
                            <th><?php echo e(trans('app.note')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $commissionPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($offset++); ?></td>
                                <td><?php echo e(displayDate($payment->paid_date)); ?></td>
                                <td><b>$ <?php echo e(decimalNumber($payment->amount, true)); ?></b></td>
                                <td><?php echo $__env->make('partial.staff-detail-link', ['agent' => $payment->staff], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo e($payment->reference_number); ?></td>
                                <td><?php echo e($payment->note); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo $commissionPayments->appends(Request::except('page'))->render(); ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/jquery-mask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/date-time-picker.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>