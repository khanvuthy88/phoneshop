<?php $__env->startSection('title', trans('app.product')); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.product')); ?></h3>
            <?php echo $__env->make('partial/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="card">
                <div class="card-header">
                    <form method="get" action="">
                        <div class="row">
                            <div class="col-lg-4">
                                <?php echo $__env->make('partial/anchor-create', [
                                    'href' => route('product.create')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                            <div class="col-lg-8 pl-1 pr-0">
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="prod_type"><?php echo e(trans('app.product_category')); ?></label>
                                        <select name="prod_type" id="prod_type" class="form-control select2">
                                            <option value=""><?php echo e(trans('app.all')); ?></option>
                                            <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($t->id); ?>" <?php echo e(request('prod_type') == $t->id ? 'selected' : ''); ?>>
                                                    <?php echo e($t->value); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="brand"><?php echo e(trans('app.brand')); ?></label>
                                        <select name="brand" id="brand" class="form-control select2">
                                            <option value=""><?php echo e(trans('app.all')); ?></option>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand->id); ?>" <?php echo e(request('brand') == $brand->id ? 'selected' : ''); ?>>
                                                    <?php echo e($brand->value); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="brand"><?php echo e(trans('app.name')); ?>/<?php echo e(trans('app.product_code/sku')); ?>/<?php echo e(trans('app.selling_price')); ?></label>
                                        <?php echo $__env->make('partial.search-input-group', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <br>
            <?php echo $__env->make('partial.item-count-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th><?php echo e(trans('app.no_sign')); ?></th>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', trans('app.name')));?></td>
                            <th><?php echo e(trans('app.photo')); ?></th>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('code', trans('app.product_code')));?></td>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sku', trans('app.sku')));?></td>
                            <th><?php echo e(trans('app.category')); ?></th>
                            <th><?php echo e(trans('app.brand')); ?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price', trans('app.price')));?></th>
                            <th><?php echo e(trans('app.action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($offset++); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo $__env->make('partial.product-photo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo e($product->code); ?></td>
                                <td><?php echo e($product->sku); ?></td>
                                <td><?php echo e($product->category->value ?? trans('app.n/a')); ?></td>
                                <td><?php echo e(brands($product->brand)); ?></td>
                                <td>$ <?php echo e(decimalNumber($product->price, true)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('product.list_warehouse', $product->id)); ?>" class="btn btn-info btn-sm mb-1">
                                        <?php echo e(trans('app.stock')); ?>

                                    </a>
                                    <?php echo $__env->make('partial.anchor-show', [
                                        'href' => route('product.show', $product->id),
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php echo $__env->make('partial.anchor-edit', [
                                        'href' => route('product.edit', $product->id),
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php echo $__env->make('partial.button-delete', [
                                        'url' => route('product.destroy', $product->id),
                                        'disabled' => 'disabled',
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $products->appends(Request::except('page'))->render(); ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select-box.js')); ?>"></script>
    <script type="text/javascript">
        $(function () {
            $('#prod_type, #brand').change(function () {
                $(this).parents('form').submit();
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>