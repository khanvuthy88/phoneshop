<a href="<?php echo e($href); ?>" class="btn btn-primary btn-sm mb-1 <?php echo e($class ?? ''); ?>" title="<?php echo e(trans('app.edit')); ?>">
    <i class="fa fa-pencil-square-o"></i>
</a>
