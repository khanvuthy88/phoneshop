<?php $__env->startSection('title', trans('app.purchase')); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-fileinput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.purchase') . ' - ' . $title); ?></h3>
            <?php echo $__env->make('partial/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form method="post" id="purchase-form" class="validated-form no-auto-submit"
                  action="<?php echo e(route('purchase.save')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row">
                    
                    <div class="col-lg-4 form-group">
                        <label for="warehouse" class="control-label">
                            <?php echo e(trans('app.location')); ?> <span class="required">*</span>
                        </label>
                        <select name="warehouse" id="warehouse" class="form-control select2" required>
                            <option value=""><?php echo e(trans('app.select_option')); ?></option>
                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($warehouse->id); ?>" <?php echo e(selectedOption($warehouse->id, old('warehouse'))); ?>>
                                    <?php echo e($warehouse->location); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div class="col-lg-4 form-group">
                        <label for="status" class="control-label">
                            <?php echo e(trans('app.purchase_status')); ?> <span class="required">*</span>
                        </label>
                        <select name="status" id="status" class="form-control select2-no-search" required>
                            <?php $__currentLoopData = $purchaseStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusKey => $statusTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($statusKey); ?>" <?php echo e(selectedOption($statusKey, old('status'))); ?>>
                                    <?php echo e($statusTitle); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div class="col-lg-4 form-group">
                        <label for="purchase_date" class="control-label">
                            <?php echo e(trans('app.purchase_date')); ?> <span class="required">*</span>
                        </label>
                        <input type="text" name="purchase_date" id="purchase_date" class="form-control date-picker" required
                               placeholder="<?php echo e(trans('app.date_placeholder')); ?>" value="<?php echo e(old('purchase_date') ?? date('d-m-Y')); ?>">
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-4 form-group">
                        <label for="product" class="control-label">
                            <?php echo e(trans('app.product')); ?>

                        </label>
                        <div class="input-group">
                            <select name="product" id="product" class="form-control select2">
                                <option value=""><?php echo e(trans('app.select_option')); ?></option>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>" <?php echo e(selectedOption($product->id, old('$product'))); ?>

                                        data-name="<?php echo e($product->name); ?>" data-code="<?php echo e($product->code); ?>">
                                        <?php echo e($product->name); ?> (<?php echo e(trans('app.code') . ' : ' . ($product->code ?? trans('app.none'))); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="button" id="add-product" class="btn btn-primary"><?php echo e(trans('app.add')); ?></button>
                        </div>
                    </div>
                </div>

                
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo e(trans('app.product_table')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="table-responsive">
                                    <table id="product-table" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(trans('app.name')); ?></th>
                                                <th><?php echo e(trans('app.code')); ?></th>
                                                <th><?php echo e(trans('app.quantity')); ?></th>
                                                <th><?php echo e(trans('app.delete')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $purchasedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr data-id="<?php echo e($product['id']); ?>">
                                                    <input type="hidden" name="products[<?php echo e($product['id']); ?>][id]" value="<?php echo e($product['id']); ?>">
                                                    <input type="hidden" name="products[<?php echo e($product['id']); ?>][name]" value="<?php echo e($product['name']); ?>">
                                                    <input type="hidden" name="products[<?php echo e($product['id']); ?>][code]" value="<?php echo e($product['code']); ?>">
                                                    <td><?php echo e($product['name']); ?></td>
                                                    <td><?php echo e($product['code'] ?? trans('app.none')); ?></td>
                                                    <td width="25%">
                                                        <input type="text" name="products[<?php echo e($product['id']); ?>][quantity]" min="1" max="10000"
                                                               class="form-control integer-input" value="<?php echo e($product['quantity']); ?>" required>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-danger btn-sm" onclick="removeProduct(this)">
                                                            <i class="fa fa-trash-o"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-4 form-group">
                        <label for="invoice_id" class="control-label">
                            <?php echo e(trans('app.invoice_id')); ?>

                        </label>
                        <input type="text" name="invoice_id" id="invoice_id" class="form-control" value="<?php echo e(old('invoice_id')); ?>">
                    </div>

                    
                    <div class="col-lg-4 form-group">
                        <label for="total_cost" class="control-label">
                            <?php echo e(trans('app.total_cost')); ?> ($)
                        </label>
                        <input type="text" name="total_cost" id="total_cost" class="form-control decimal-input"
                               min="1" value="<?php echo e(old('total_cost')); ?>">
                    </div>

                    
                    <div class="col-lg-4 form-group">
                        <label for="discount" class="control-label">
                            <?php echo e(trans('app.discount')); ?> ($)
                        </label>
                        <input type="text" name="discount" id="discount" class="form-control decimal-input"
                               min="0" value="<?php echo e(old('discount')); ?>">
                    </div>
                </div>
                <div class="row">
                    
                    <div class="col-lg-4 form-group">
                        <label for="shipping_cost" class="control-label">
                            <?php echo e(trans('app.shipping_cost')); ?> ($)
                        </label>
                        <input type="text" name="shipping_cost" id="shipping_cost" class="form-control decimal-input"
                               min="0" value="<?php echo e(old('shipping_cost')); ?>">
                    </div>

                    
                    <div class="col-lg-4 form-group">
                        <label for="document" class="control-label">
                            <?php echo e(trans('app.document')); ?>

                        </label>
                        <input type="file" name="document" id="document" class="form-control">
                    </div>

                    
                    <div class="col-lg-4 form-group">
                        <label for="note" class="control-label">
                            <?php echo e(trans('app.note')); ?>

                        </label>
                        <input type="text" name="note" id="note" class="form-control" value="<?php echo e(old('note')); ?>">
                    </div>
                </div>

                
                <div class="row">
                    <div class="col-lg-12 text-right">
                        <?php echo $__env->make('partial/button-save', ['onClick' => 'confirmFormSubmission($("#purchase-form"))'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        var noneLabel = '<?php echo e(trans('app.none')); ?>';
    </script>
    <script src="<?php echo e(asset('js/bootstrap-fileinput.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-fileinput-fa-theme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/init-file-input.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-number.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/number.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-mask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mask.js')); ?>"></script>
    <script src="<?php echo e(asset('js/date-time-picker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select-box.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/form-validation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/purchase.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>