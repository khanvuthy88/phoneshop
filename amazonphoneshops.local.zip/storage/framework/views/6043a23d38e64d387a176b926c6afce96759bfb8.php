<label class="badge badge-success">
    <?php echo trans('app.total_items') . ' : <b>' . ($itemCount ?? trans('app.n/a')) . '</b>'; ?>

</label>
