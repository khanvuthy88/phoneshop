<a href="<?php echo e($href); ?>" class="btn btn-success btn-sm mb-1 <?php echo e($class ?? ''); ?>" title="<?php echo e(trans('app.view_detail')); ?>">
    <i class="fa fa-eye"></i>
</a>
