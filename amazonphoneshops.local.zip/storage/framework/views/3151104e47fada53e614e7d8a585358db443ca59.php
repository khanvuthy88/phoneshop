<?php $__env->startSection('title', trans('app.purchase')); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<main class="app-content">
    <div class="tile">
        <h3 class="page-heading"><?php echo e(trans('app.purchase') . ' - ' . trans('app.detail')); ?></h3>
        <?php echo $__env->make('partial.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
            <div class="col-lg-6">
                <h5><?php echo e(trans('app.purchase_info')); ?></h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <tbody>
                            <tr>
                                <td width="30%"><?php echo e(trans('app.purchase_date')); ?></td>
                                <td><?php echo e(displayDate($purchase->purchase_date)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.purchase_status')); ?></td>
                                <td><?php echo $__env->make('partial.purchase-status-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.location')); ?></td>
                                <td><?php echo $__env->make('partial.branch-detail-link', ['branch' => $purchase->warehouse], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.invoice_id')); ?></td>
                                <td><?php echo e($purchase->reference_no); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.total_cost')); ?></td>
                                <td>$ <?php echo e(decimalNumber($purchase->total_cost, true)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.discount')); ?></td>
                                <td>$ <?php echo e(decimalNumber($purchase->total_discount, true)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.shipping_cost')); ?></td>
                                <td>$ <?php echo e(decimalNumber($purchase->shipping_cost, true)); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.document')); ?></td>
                                <td><?php echo $__env->make('partial.purchase-doc-view', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(trans('app.note')); ?></td>
                                <td><?php echo $purchase->note; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-6">
                <h5><?php echo e(trans('app.product_table')); ?></h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th><?php echo e(trans('app.no_sign')); ?></th>
                                <th><?php echo e(trans('app.product')); ?></th>
                                <th><?php echo e(trans('app.quantity')); ?></th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchase->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo $__env->make('partial.product-detail-link', ['product' => $purchaseDetail->product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                    <td><?php echo e($purchaseDetail->quantity); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>