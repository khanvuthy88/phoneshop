<?php $__env->startSection('title', trans('app.sale')); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="tile">
            <h3 class="page-heading"><?php echo e(trans('app.sale')); ?></h3>
            <?php echo $__env->make('partial.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card">
                <div class="card-header">
                    <form method="get" action="">
                        <div class="row">
                            <div class="col-lg-6">
                                <?php echo $__env->make('partial.anchor-create', [
                                    'href' => route('sale.create')
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                            <div class="col-lg-6">
                                <?php echo $__env->make('partial.search-input-group', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <br>

            <?php echo $__env->make('partial.item-count-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th><?php echo e(trans('app.no_sign')); ?></th>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sale_date', trans('app.sale_date')));?></td>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sale_code', trans('app.sale_code')));?></td>
                            <th><?php echo e(trans('app.location')); ?></th>
                            <th><?php echo e(trans('app.client')); ?></th>
                            <th><?php echo e(trans('app.agent')); ?></th>
                            <th><?php echo e(trans('app.total_amount')); ?></th>
                            <th><?php echo e(trans('app.paid_amount')); ?></th>
                            <th><?php echo e(trans('app.status')); ?></th>
                            <th><?php echo e(trans('app.action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($offset++); ?></td>
                                <td><?php echo e(displayDate($sale->sale_date)); ?></td>
                                <td><?php echo e($sale->sale_code); ?></td>
                                <td><?php echo $__env->make('partial.branch-detail-link', ['branch' => $sale->warehouse], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo $__env->make('partial.client-profile-photo', ['client' => $sale->client], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td><?php echo $__env->make('partial.staff-detail-link', ['staff' => $sale->staff], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td>$ <?php echo e(decimalNumber($sale->grand_total, true)); ?></td>
                                <td>$ <?php echo e(decimalNumber($sale->paid_amount, true)); ?></td>
                                <td><?php echo $__env->make('partial.sale-status-label', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td class="text-center">
                                    <?php echo $__env->make('partial.anchor-show', [
                                        'href' => route('sale.show', $sale->id)
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $sales->appends(Request::except('page'))->render(); ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select-box.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>