<a href="<?php echo e(route('branch.show', $branch->id)); ?>"><?php echo e($branch->location); ?></a>
