<a href="<?php echo e(route('staff.show', $staff->id)); ?>">
    <?php echo e($staff->name); ?>

</a>
