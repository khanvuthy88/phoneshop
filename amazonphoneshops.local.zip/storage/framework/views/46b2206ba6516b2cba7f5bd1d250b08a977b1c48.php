<?php switch($purchase->purchase_status):
    case (PurchaseStatus::RECEIVED): ?>
    <label class="badge badge-success"><?php echo e(purchaseStatuses($purchase->purchase_status)); ?></label>
    <?php break; ?>
    <?php case (PurchaseStatus::ORDERED): ?>
    <label class="badge badge-warning"><?php echo e(purchaseStatuses($purchase->purchase_status)); ?></label>
    <?php break; ?>
<?php endswitch; ?>
