<?php

namespace App\Constants;

class ExtendedProperty
{
    const BRAND = 'b';
    const POSITION = 'p';
    const PRODUCT_CATEGORY = 'pc';
}
