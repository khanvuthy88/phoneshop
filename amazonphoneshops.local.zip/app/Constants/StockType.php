<?php

namespace App\Constants;

class StockType
{
    const STOCK_IN = 'si';
    const STOCK_OUT = 'so';
}
