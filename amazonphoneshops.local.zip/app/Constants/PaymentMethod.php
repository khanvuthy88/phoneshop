<?php

namespace App\Constants;

class PaymentMethod
{
    const DIRECT_PAYMENT = 'dp';
    const BANK = 'b';
    const WING = 'w';
    const TRUE_MONEY = 'tm';
    const E_MONEY = 'em';
}
