<?php

namespace App\Constants;

class Gender
{
    const MALE = 'm';
    const FEMALE = 'f';
}
