<?php

namespace App\Constants;

class PurchaseStatus
{
    const ORDERED  = 'o';
    // const PENDING = 'p';
    const RECEIVED = 'r';
}