<?php

namespace App\Constants;

class SaleType
{
    const SALE = 'sl';
    const POS = 'po';
}