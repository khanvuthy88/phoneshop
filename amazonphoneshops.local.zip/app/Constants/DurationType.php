<?php

namespace App\Constants;

class DurationType
{
    const YEARLY = 'y';
    const MONTHLY = 'm';
    const WEEKLY = 'w';
    const DAILY = 'd';
}