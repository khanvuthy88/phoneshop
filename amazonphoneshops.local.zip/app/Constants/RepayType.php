<?php

namespace App\Constants;

class RepayType
{
    const REPAY = 1;
    const PAYOFF = 2;
    const ADVANCE_PAY = 3;
}
