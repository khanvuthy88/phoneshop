<?php

namespace App\Constants;

class PaymentScheduleType
{
    const FLAT_INTEREST = 'fi';
    const DECLINE_INTEREST = 'di';
    const EQUAL_PAYMENT = 'ep';
}