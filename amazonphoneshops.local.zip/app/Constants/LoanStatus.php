<?php

namespace App\Constants;

class LoanStatus
{
    const PENDING = 'p';
    // const APPROVED = 'ap';
    const ACTIVE = 'ac';
    const PAID = 'pa';
    const REJECTED = 'r';
}
