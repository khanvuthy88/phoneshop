<?php

namespace App\Constants;

class StockTransferStatus
{
    const COMPLETED = 'cp';
    const SENT = 'st';
    const PENDING = 'pd';
}
