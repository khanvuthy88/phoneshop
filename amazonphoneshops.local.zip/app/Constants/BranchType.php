<?php

namespace App\Constants;

class BranchType
{
    const SHOP = 's';
    const WAREHOUSE = 'w';
}
