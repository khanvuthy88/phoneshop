<?php

namespace App\Constants;

class SaleStatus
{
    const DRAFT = 'df';
    const PENDING = 'pd';
    const ACTIVE = 'at';
    const PAID = 'pa';
    const DONE = 'do';
}