<?php

namespace App\Constants;

class FormType
{
    const CREATE_TYPE = 'ct';
    const EDIT_TYPE = 'et';
    const SHOW_TYPE = 'st';
}
