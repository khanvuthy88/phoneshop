<?php

namespace App\Constants;

class MaritalStatus
{
    const SINGLE = 's';
    const MARRIED = 'm';
}
