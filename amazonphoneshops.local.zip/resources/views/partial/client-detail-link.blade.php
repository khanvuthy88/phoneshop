<a href="{{ route('client.show', $client) }}">{{ $client->name }}</a>
