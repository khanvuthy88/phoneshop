<a href="{{ route('staff.show', $staff->id) }}">
    {{ $staff->name }}
</a>
