<a href="{{ route('branch.show', $branch->id) }}">{{ $branch->location }}</a>
