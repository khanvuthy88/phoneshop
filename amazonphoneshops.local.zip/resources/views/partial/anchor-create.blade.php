<a href="{{ $href }}" class="btn btn-success mb-1 {{ $class ?? '' }}" title="{{ trans('app.create') }}">
    <i class="fa fa-plus-circle pr-1"></i> {{ trans('app.create') }}
</a>
