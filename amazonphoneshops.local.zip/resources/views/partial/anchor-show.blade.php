<a href="{{ $href }}" class="btn btn-success btn-sm mb-1 {{ $class ?? '' }}" title="{{ trans('app.view_detail') }}">
    <i class="fa fa-eye"></i>
</a>
