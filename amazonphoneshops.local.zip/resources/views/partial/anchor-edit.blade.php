<a href="{{ $href }}" class="btn btn-primary btn-sm mb-1 {{ $class ?? '' }}" title="{{ trans('app.edit') }}">
    <i class="fa fa-pencil-square-o"></i>
</a>
