<a href="{{ route('product.show', $product) }}">{{ $product->name }}</a>
