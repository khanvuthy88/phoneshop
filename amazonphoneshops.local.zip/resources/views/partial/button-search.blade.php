<button type="submit" class="btn btn-success {{ $class ?? '' }}">
    <i class="fa fa-search pr-1"></i> {{ trans('app.search') }}
</button>
