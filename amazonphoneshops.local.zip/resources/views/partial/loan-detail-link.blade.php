<a href="{{ route('loan.show', $loan) }}">
    {{ $loan->client_code }}
</a>
